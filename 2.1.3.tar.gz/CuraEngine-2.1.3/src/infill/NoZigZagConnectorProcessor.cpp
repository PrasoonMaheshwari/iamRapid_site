/** Copyright (C) 2016 Ultimaker - Released under terms of the AGPLv3 License */
#include "NoZigZagConnectorProcessor.h"


namespace cura 
{

void NoZigZagConnectorProcessor::registerVertex(const Point& vertex)
{

}

void NoZigZagConnectorProcessor::registerScanlineSegmentIntersection(const Point& intersection, bool scanline_is_even)
{

}

void NoZigZagConnectorProcessor::registerPolyFinished()
{

}



} // namespace cura 
