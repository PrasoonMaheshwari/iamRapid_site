Glossary
========


Term/Synonyms | Meaning
--- | ---
Extruder Train | The whole of a feeder, bowden tube and a nozzle
Island/Part | isolated/unconnected part in 2D slice
Inset | perimeter, the perimeters which are laid down around the infill
Slicing | The act of extracting the contours of the object at a certain height (not the whole process which would also include gcode generation etc.)
Tower (support) | A strut to reinforce parts of the support which would otherwise be unstable.
Weaver / Neith / WirePrint | A non-layer-wise form of printing 'in thin air'