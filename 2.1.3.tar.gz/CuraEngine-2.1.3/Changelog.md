Changelog CuraEngine
====================




- Feature: infill_wipe_dist. Add a travel move after an infill line in order to let it stick better to the walls.
- Feature: Draft Protection Screen. A shell similar to the ooze shield providing protection from gusts of wind and acting similar to a heated chamber


Release 15.06.01
-----

- [Not documented]